# // Roomba_skeleton
# ROS Imports
import rclpy
from rclpy.node import Node
from rclpy.action.client import ActionClient
from rclpy.callback_groups import MutuallyExclusiveCallbackGroup
from rclpy.executors import SingleThreadedExecutor
from rclpy.executors import MultiThreadedExecutor
from rclpy.qos import qos_profile_sensor_data


# Create3 Packages
from irobot_create_msgs.action import DriveDistance, Undock, RotateAngle, AudioNoteSequence
from irobot_create_msgs.msg import AudioNote, AudioNoteVector
from irobot_create_msgs.srv import ResetPose
from builtin_interfaces.msg import Duration
from std_msgs.msg import String
from nav_msgs.msg import Odometry
from irobot_create_msgs.msg import IrIntensityVector, IrOpcode

# Python Packages
import random
import time
from threading import RLock
from std_msgs.msg import Float32, UInt8, Int8 # Some topics have specific datatypes


class Dock_Node(Node):
    def __init__(self, namespace):
        super().__init__('publisher')
        # Create the publishers for the /ir_opcode and /ir_intensity topics
        self.opcode_publisher = self.create_publisher(UInt8, 'ir_opcode', 10)
        self.intensity_publisher = self.create_publisher(Int8, 'ir_intensity', 10)

        cb_Action = MutuallyExclusiveCallbackGroup()

        # Actions
        self._drive_ac = ActionClient(self, DriveDistance, f'/{namespace}/drive_distance', callback_group=cb_Action)
        self._rotate_ac = ActionClient(self, RotateAngle, f'/{namespace}/rotate_angle', callback_group=cb_Action)

        # Subscriptions
        self._opcode_subscriber, = self.create_subscription(IrOpcode, f'/{namespace}/ir_opcode', self.listener_1, qos_profile_sensor_data)
        self._intensity_subscriber, = self.create_subscription(IrIntensityVector, f'/{namespace}/ir_intensity', self.listener_2, qos_profile_sensor_data)

        self.curValue_1 = None  # Initialize curValue_1 to None
        self.poll_called = False

    def listener_1(self, msg_1):
        """
        This will be called everytime the subscriber receives a new message from the topic
        """
        self.curValue_1 = msg_1.sensor
        self.poll_called = False
        print(self.curValue_1)

    def listener_2(self, msg_2):
        """
        This will be called everytime the subscriber receives a new message from the topic
        """
        self.curValue_2 = msg_2.readings
        for i in self.curValue_2:
            return(f"IR Intensity: {i.header.frame_id}, {i.value}")

    def sendDriveGoal(self, goal):
        """
        Sends a drive goal asynchronously and 'blocks' until the goal is complete
        """
        with RLock:
            drive_handle = self._drive_ac.send_goal_async(goal)
            while not drive_handle.done():
                pass  # Wait for Action Server to accept goal


    def ir_intensity_poll(self):
        if self.curValue_2 is not None and len(self.curValue_2) > 0:
            # Print only the first message from readings
            first_reading1 = self.curValue_2[0]
            first_reading2 = self.curValue_2[1]
            first_reading3 = self.curValue_2[2]
            first_reading4 = self.curValue_2[3]
            first_reading5 = self.curValue_2[4]
            first_reading6 = self.curValue_2[5]
            first_reading7 = self.curValue_2[6]
            first_reading8 = self.curValue_2[7]
            print("IR Intensity 1: ", first_reading1.header.frame_id, " ", first_reading1.value)
            print("IR Intensity 2: ", first_reading2.header.frame_id, " ", first_reading2.value)
            print("IR Intensity 3: ", first_reading3.header.frame_id, " ", first_reading3.value)
            print("IR Intensity 4: ", first_reading4.header.frame_id, " ", first_reading4.value)
            print("IR Intensity 5: ", first_reading5.header.frame_id, " ", first_reading5.value)
            print("IR Intensity 6: ", first_reading6.header.frame_id, " ", first_reading6.value)
            print("IR Intensity 7: ", first_reading7.header.frame_id, " ", first_reading7.value)
            print("IR Intensity 8: ", first_reading8.header.frame_id, " ", first_reading8.value)

            if first_reading1.value > first_reading7.value:
                # Take action for IR Intensity 1 - Side left
                print("Taking action for IR Intensity 1")
                self.rotate_angle_ac.wait_for_server()
                self.get_logger().warning('TURNING!')
                rotate_angle_goal = RotateAngle.Goal()
                rotate_angle_goal.angle = 0.3
                self.sendRotateGoal(rotate_angle_goal)

            if first_reading2.value > first_reading7.value:
                # Take action for IR Intensity 2 - Left
                print("Taking action for IR Intensity 2")
                self.rotate_angle_ac.wait_for_server()
                self.get_logger().warning('TURNING!')
                rotate_angle_goal = RotateAngle.Goal()
                rotate_angle_goal.angle = 0.2
                self.sendRotateGoal(rotate_angle_goal)

