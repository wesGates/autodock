# ROS Imports
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from rclpy.action.client import ActionClient
from rclpy.action.client import GoalStatus
from rclpy.callback_groups import MutuallyExclusiveCallbackGroup
from geometry_msgs.msg import PoseStamped
from action_msgs.msg import GoalStatus
from std_msgs.msg import String, Int32, Float32, UInt8, Int16 # Some topics have specific datatypes (POTENTIALLY USELESS!!!)


# Create3 Packages
import irobot_create_msgs
from irobot_create_msgs.srv import ResetPose
from irobot_create_msgs.action import DriveDistance, Undock, RotateAngle, Dock, NavigateToPosition, AudioNoteSequence
from irobot_create_msgs.msg import HazardDetectionVector, AudioNoteVector, AudioNote, IrIntensityVector, IrOpcode
from builtin_interfaces.msg import Duration

# key_commander stuff
from pynput.keyboard import KeyCode
from key_commander import KeyCommander

# Python Packages
import random, time

# Threading
from rclpy.executors import MultiThreadedExecutor
from threading import RLock

# Node Imports
from Dock_Status_Node import Dock_Status_Node
from Dock_Node import Dock_Node

rclpy.init()
namespace = 'create3_0561'

# Connect to other nodes
sensor = Dock_Status_Node(namespace) # dock
dock = Dock_Node(namespace)
# singing = Song(namespace)


class Roomba(Node):
    def __init__(self, namespace):
        super().__init__('Roomba')

        # 2 Separate Callback Groups for handling the bumper Subscription and Action Clients ####################
        cb_Subscription = MutuallyExclusiveCallbackGroup()
        cb_Subscription1 = MutuallyExclusiveCallbackGroup()
        cb_Subscription2 = MutuallyExclusiveCallbackGroup()
        cb_Action = MutuallyExclusiveCallbackGroup()
        cb_srv = MutuallyExclusiveCallbackGroup()

        # Subscription to Hazards, Dock status, and IR intensity the callback function attached only looks for bumper
        # self.subscription = self.create_subscription(HazardDetectionVector, f'/{namespace}/hazard_detection', self.listener_1, 10, callback_group=cb_Subscription)
        self.subscription1 = self.create_subscription(String, 'check_dock_status', self.listener_1, 10, callback_group=cb_Subscription1)
        self.subscription2 = self.create_subscription(IrIntensityVector, f'/{namespace}/ir_intensity', self.listener_2, 10, callback_group=cb_Subscription2)

        # Subscription to Music, callback looks for AudioNotes
        self.subscription2 = self.create_subscription(IrOpcode, f'/{namespace}/ir_opcode', self.listener_1, 10, callback_group=cb_Subscription2)

        # Action clients for movements
        self.undock_ac = ActionClient(self, Undock, f'/{namespace}/undock', callback_group=cb_Action)
        self.drive_ac = ActionClient(self, DriveDistance, f'/{namespace}/drive_distance', callback_group=cb_Action)
        self.rotate_ac = ActionClient(self, RotateAngle, f'/{namespace}/rotate_angle', callback_group=cb_Action)
        self.navigate_to_position_ac = ActionClient(self, NavigateToPosition, f'/{namespace}/navigate_to_position', callback_group=cb_Action)
        self.audio_note_sequence_ac = ActionClient(self, AudioNoteSequence, f'/{namespace}/audio_note_sequence', callback_group=cb_Action)

        self.reset_pose = self.create_client(ResetPose, f'/{namespace}/reset_pose', callback_group=cb_srv)

        self._goal_uuid = None        # Subscription to Hazards, Dock status, and IR intensity the callback function attached only looks for bumper

    def listener_1(self, msg):
        print('I got: ', msg.data)

    def listener_2(self, msg_2):
        pass
        for i in msg_2.readings:
            print('IR Intensity: ', i.header.frame_id, ' ', i.value)

    def listener_callback(self, msg):
        if self._goal_uuid is None:
            return

        for detection in msg.detections:
            if detection.type == 1:  # If it is a bump
                self.get_logger().warning('HAZARD DETECTED')
                with RLock():  # Assuming RLock is properly imported and instantiated elsewhere
                    # Make this the only thing happening
                    self.get_logger().warning('CANCELING GOAL')
                    # Assuming there is an action client attribute named appropriately, such as self.some_action_client
                    self.some_action_client.cancel_goal_async(self._goal_uuid)
                    self._goal_uuid = None  # Reset the goal UUID after canceling


    # def created_dock():
    #     note_vector = AudioNoteVector()
    #     note_vector.notes.append(AudioNote(frequency=1000, max_runtime=Duration(sec=1)))
    #     note_vector.notes.append(AudioNote(frequency=500, max_runtime=Duration(sec=1)))

    #     song = AudioNoteSequence.Goal()
    #     song.notes_sequence = note_vector
    #     singing.play_audio(song)

    #     created_dock.ir_opcode_poll()
    #     created_dock.ir_intensity_poll()

    #     max_attempts = 10
    #     attempts = 0

    #     while attempts < max_attempts:
    #         attempts += 1
    #         sensor.poll()
    #         cur_value = sensor.curValue
    #         if cur_value == 'True':
    #             print("The sensor indicates docking.")
    #             break
    #         # Add your actions here
    #         elif cur_value == 'False':
    #             created_dock.ir_intensity_poll()
    #         time.sleep(1)


if __name__ == '__main__':
    rclpy.init()

    Roomba = Roomba(namespace)
    exec = MultiThreadedExecutor(10)
    exec.add_node(Roomba)
    exec.add_node(sensor)
    exec.add_node(created_dock)
    # exec.add_node(singing)

    keycom = KeyCommander([
        (KeyCode(char='s'), s.sequencer),
    ])

    print("Start drive_away")
    try:
        exec.spin()  # execute Roomba callbacks until shutdown or destroy is called
    except KeyboardInterrupt:
        print("KeyboardInterrupt, shutting down.")
    except Exception as e:
        print(f"Unexpected error: {e}")
    finally:
        print("Shutting down executor")
        exec.shutdown()
        print("Destroying node")
        s.destroy_node()
        print("Shutting down RCLpy")
        rclpy.try_shutdown()

# Prepare Data for back
